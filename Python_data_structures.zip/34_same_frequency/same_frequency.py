def same_frequency(num1, num2):
    """Do these nums have same frequencies of digits?
    
        >>> same_frequency(551122, 221515)
        True
        
        >>> same_frequency(321142, 3212215)
        False
        
        >>> same_frequency(1212, 2211)
        True
    """
    num1 = str(num1)
    num2 = str(num2)
    one = set(num1)
    two = set(num2)
    
    one_dict = {x: num1.count(x) for x in one}
    two_dict = {x: num2.count(x) for x in two}

    return one_dict == two_dict