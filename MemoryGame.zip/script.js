const gameContainer = document.getElementById("game");
let cards = [];
let gameActive = false;
let totalGuesses = 0;
let highScore = parseInt(localStorage.getItem('highscore'));

const COLORS = [
  "red",
  "blue",
  "green",
  "orange",
  "purple",
  "black",
  "yellow",
  "silver"
];

let matches = 0;

// here is a helper function to shuffle an array
// it returns the same array with values shuffled
// it is based on an algorithm called Fisher Yates if you want ot research more
function shuffle(array) {

  fullArray=[];

  for(let i = 0; i < array.length; i++){
    fullArray.push(array[i]);
    fullArray.push(array[i]);
  }

  array=fullArray;
  fullArray = null;

  let counter = array.length;

  // While there are elements in the array
  while (counter > 0) {
    // Pick a random index
    let index = Math.floor(Math.random() * counter);

    // Decrease counter by 1
    counter--;

    // And swap the last element with it
    let temp = array[counter];
    array[counter] = array[index];
    array[index] = temp;
  }

  return array;
}

let shuffledColors = shuffle(COLORS);

// this function loops over the array of colors
// it creates a new div and gives it a class with the value of the color
// it also adds an event listener for a click for each card
function createDivsForColors(colorArray) {
  for (let color of colorArray) {
    // create a new div
    const newDiv = document.createElement("div");

    // give it a class attribute for the value we are looping over
    newDiv.classList.add(color);

    // append the div to the element with an id of game
    gameContainer.append(newDiv);
  }
}

// when the DOM loads
createDivsForColors(shuffledColors);
const startButton = document.createElement("button");
startButton.innerText = 'start game';
const resetButton = document.createElement("button");
resetButton.innerText = 'reset board';
resetButton.style.visibility = 'hidden';
const runningScore = document.createElement("div");
runningScore.innerText = `Total guesses = ${totalGuesses}`;

const body = document.querySelector('body');
body.append(startButton);
body.append(resetButton);
body.append(runningScore);

function compareCards() {
    const pair1 = cards[0];
    const pair2 = cards[1];
    totalGuesses++;
    runningScore.innerText = `Total guesses = ${totalGuesses}`;

    if (pair1.style.backgroundColor === pair2.style.backgroundColor) {
          console.log("it's a match!");
          matches++;
          cards.length = 0;
          if (matches === COLORS.length/2) {
            console.log(localStorage.getItem('highscore'));
            if (totalGuesses < parseInt(localStorage.getItem('highscore')) || localStorage.getItem('highscore') == null) {
              localStorage.setItem('highscore', totalGuesses);
            }
            resetButton.style.visibility = 'visible';
          }
    } else {
      setTimeout(function() {
          pair1.style.backgroundColor = "";
          pair2.style.backgroundColor = "";
          cards.length = 0;
      }, 1000);
    }
}

gameContainer.addEventListener("click", function(e) {
    const box = e.target;

    if (gameActive) {
      if (box.tagName === "DIV" && box.style.backgroundColor === "" && cards.length <= 1) {
        box.style.backgroundColor = box.className;
        if (cards.length === 0) {
            cards.push(box);
        } else {
            cards.push(box);
            compareCards();
        }
      }
    }
});

startButton.addEventListener("click", function(e) {
    gameActive = true;
    startButton.style.visibility = 'hidden';
});

resetButton.addEventListener("click", function(e) {
    const allBoxes = document.querySelectorAll("#game div");
    for (let box of allBoxes) {
      box.style.backgroundColor = "";
    }
    gameActive = false;
    totalGuesses = 0;
    startButton.style.visibility = 'visible';
    resetButton.style.visibility = 'hidden';
    runningScore.innerText = `Total guesses = ${totalGuesses}`;
});