"""Word Finder: finds random words from a dictionary."""


class WordFinder:
    
    def __init__(self):
        """create word list object. run read_words()"""
        self.array = []
        self.setarray = self.read_words()

    def read_words(self):
        """read words in file into list object. return set object of the list object"""
        file = open('words.txt', 'r')
        count = 0
        for line in file:
            count +=1
            self.array.append(line.strip())
        print(f"{count} words read")
        return set(self.array)

    def random(self):
        """return random word from set of words"""
        return self.setarray.pop()

class SpecialWordFinder(WordFinder):

    def __init__(self):
    # get parent class [`super()`], call its `__init__()`
        super().__init__()

    def read_words(self):
        file = open('special_words.txt', 'r')
        count = 0
        for line in file:
            line = line.strip()
            if line.startswith("#") or line == '':
                continue
            count +=1
            self.array.append(line)
        print(f"{count} words read")
        return set(self.array)


