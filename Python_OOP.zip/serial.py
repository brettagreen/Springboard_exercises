"""Python serial number generator."""

class SerialGenerator:
    """Machine to create unique incrementing serial numbers.
    
    >>> serial = SerialGenerator(start=100)

    >>> serial.generate()
    100

    >>> serial.generate()
    101

    >>> serial.generate()
    102

    >>> serial.reset()

    >>> serial.generate()
    100
    """
    def __init__(self, start):
        """capture initial value in start and next, subtract one"""
        self.start = start - 1
        self.next = start - 1
    
    def __repr__(self):
        return f"<SerialGenerator start={self.start} next={self.next}>"
    
    def generate(self):
        """return value of next + 1"""
        self.next +=1
        return self.next

    def reset(self):
        """reset next value to (initial) start value"""
        self.next = self.start

