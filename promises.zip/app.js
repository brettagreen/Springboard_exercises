//1.

/*$(document).ready(function() {
    let myPromise = $.getJSON('http://numbersapi.com/9/trivia/?json')
    myPromise.then(response => {
        console.log(response.text)
    })
})*/

//2.

/*$(document).ready(function() {
    const li = $('li');
    const min = 9;
    const max = 13;
    let myPromise = $.getJSON(`http://numbersapi.com/${min}..${max}/trivia/?json`);
    myPromise.then(response => {
        for (let x = min; x <= max; x++) {
            li.append('<ul>'+response[x.toString()]+'</ul>')
            console.log(response[x.toString()])
        }
    })
})*/

//3.

/*let numberPromises = [];

for (let i = 1; i < 5; i++) {
  numberPromises.push(
    $.getJSON('http://numbersapi.com/9/trivia/?json')
  );
}

Promise.all(numberPromises).then(facts => (
    facts.forEach(fact => 
        $('li').append('<ul>'+fact.text+'</ul>')
        )
  )).catch(err => console.log(err));*/

  ////////////////////////////////////////////////////////////////////
  //////DECK O' CARDS////////////////////////////////////////////////
//1.

/*$(document).ready(function() {
  const url_shuffle = 'https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1';

  $.getJSON(url_shuffle)
  .then(resp => {
    return $.getJSON(`https://deckofcardsapi.com/api/deck/${resp.deck_id}/draw/?count=1`);
  })
  .then(resp => {
    console.log(resp.cards["0"].value + ' of ' + resp.cards["0"].suit)
  })
})*/

//2.

/*$(document).ready(function() {
    const url_shuffle = 'https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1';
    let card1 = null;
    let card2 = null;
    let deckId = null;
  
    $.getJSON(url_shuffle)
    .then(resp => {
      deckId = resp.deck_id
      return $.getJSON(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`);
    })
    .then(resp => {
      card1 = resp.cards['0'];
      return $.getJSON(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`);
    })
    .then(resp => {
      card2 = resp.cards['0'];
      console.log("Card 1: " + card1.value + ' of ' + card1.suit);
      console.log("Card 2: " + card2.value + ' of ' + card2.suit);
    })
  })*/

  //3.
  
  /*$(document).ready(function() {
    const button = $('#button');
    const displayArea = $('#display');
    let deckId = null;
    let url_draw = null;

    $.getJSON('https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1')
    .then(resp => {
        deckId = resp.deck_id;
        url_draw = `https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`;
    })

    $(button).on('click', function() {
        $.getJSON(url_draw)
        .then(resp => {
            console.log(resp.remaining);
            if ($('img').length) {
                $('img').remove();
            }
            displayArea.append(
                $('<img>', {
                src: resp.cards['0'].image
                })
            );
            if (resp.remaining === 0) {
                button.remove();
                displayArea.append('<h2>That\'s the last card!</h2>');
            }
        })
    })
  })*/

  ////////////////////////////////////////////////////////////////////
  //////FURTHER STUDY////////////////////////////////////////////////
  $(document).ready(function() {

    const fetchThemPokeMen = 'http://pokeapi.co/api/v2/pokemon/';
    const pokeArray = [];
    let count = null;

    $.getJSON(`${fetchThemPokeMen}?limit=1500`)
    .then(resp => {
        count = resp.count;
        for (let x = 0; x < 3; x++) {
            const value = Math.floor(Math.random() * (count - 0 + 1));
            pokeArray.push(resp.results[value].url);
        }
        return Promise.all(pokeArray)
    })
    .then(urls => {
            urls.forEach(url => {
                let name = null;
                $.getJSON(url).then(stats => {
                    name = stats.name;
                    return $.getJSON(stats.species.url)
                }).then(resp => {
                    for (let x = 0; x < (resp.flavor_text_entries).length; x++) {
                        
                        if (resp.flavor_text_entries[x].language.name === 'en') {
                            console.log(name + ": " + resp.flavor_text_entries[x].flavor_text);
                            break;
                        }
                    }
                })
            })
    }).catch(err => console.log(err));    
  })