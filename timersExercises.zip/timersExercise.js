/*function countDown(num){
    let timer = setInterval(function(){
      num--;
      if(num <= 0){
        console.log("0");
        console.log('DONE!');
        clearInterval(timer);
      }
      else {
        console.log(num);
      }
  
    },1000)
  }

  countDown(5);*/

  function randomGame() {
    let counter = 1;
    let timer = setInterval(function() {
        let num = Math.random();
        console.log(num);
        if (num > .75) {
            console.log(counter);
            console.log("number of tries = " + counter);
            clearInterval(timer);
        } else {
            counter++;
        }
    }, 1000);

  }

randomGame();