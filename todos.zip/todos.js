//would think that saving the individual li html object to local storage would work.
//that would allow for completed elements to keep the strikethrough text on reload.


const form = document.querySelector("form");
const list = document.querySelector("#todo-list");

form.addEventListener("submit", function(e) {
    e.preventDefault();
    const formField = document.getElementById("item");

    const taskText = formField.value;

    createListItem(taskText);

    console.log(taskItem);
    localStorage.setItem(formField.value, formField.value);

    formField.value = '';
});

list.addEventListener("click", function(e) {
    if (e.target.tagName === "BUTTON" && e.target.innerText === "mark complete") {
        e.target.parentElement.classList.add("completed");
        e.target.remove();
    } else if (e.target.tagName === "BUTTON" && e.target.innerText === "remove") {
        const key = e.target.parentElement.firstChild.innerText;
        console.log(key);
        localStorage.removeItem(key);
        e.target.parentElement.remove();
    }
});

window.addEventListener('DOMContentLoaded', function(e) {
    //modified code/logic as taken from https://iqcode.com/code/javascript/how-to-get-all-items-in-localstorage

    keys = Object.keys(localStorage);
    rows = keys.length;

    if (rows > 0) {
        while (rows--) {
            console.log(localStorage.getItem(keys[rows]));
            createListItem(localStorage.getItem(keys[rows]));
        }
    }
});

function createListItem(taskText) {
    const taskItem = document.createElement("li");
    taskItem.innerHTML = "<span>" + taskText + "</span>";
    list.append(taskItem);
    let doneButton = document.createElement("button");
    let removeButton = document.createElement("button");
    doneButton.innerText = "mark complete";
    removeButton.innerText = "remove";

    taskItem.append(doneButton);
    taskItem.append(removeButton);

    list.append(taskItem);
}