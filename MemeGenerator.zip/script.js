const form = document.querySelector("form");
const ul = document.querySelector('ul');

let url = document.getElementById("image");
let topText = document.querySelector("#text-top");
let bottomText = document.querySelector("#text-bottom");

function renderMeme() {
    const listItem = document.createElement("li");
    const imageDiv = document.createElement("div");
    const image = document.createElement("img");
    const removeButton = document.createElement("button");
    const textDivTop = document.createElement("div");
    const textDivBottom = document.createElement("div");

    ul.append(listItem);
    listItem.append(imageDiv);
    imageDiv.append(textDivTop)
    imageDiv.append(image);
    imageDiv.append(textDivBottom);
    imageDiv.append(removeButton);

    removeButton.innerText = 'meme go bye-bye!'
    removeButton.className = "remove-button"

    image.setAttribute('src', url.value);
    image.setAttribute('alt', 'meme image');
    image.setAttribute('height', 400);
    image.setAttribute('width', 400);
    textDivTop.className = 'meme-text';
    textDivBottom.className = 'meme-text';
    textDivTop.innerText = topText.value.toUpperCase();
    textDivBottom.innerText = bottomText.value.toUpperCase();

    imageDiv.style.position = 'relative';
    imageDiv.id = "image-div";
    textDivTop.id = "textDiv-top";
    textDivBottom.id = "textDiv-bottom";

    url.value = '';
    topText.value = '';
    bottomText.value = '';
}

form.addEventListener("submit", function(e) {
    e.preventDefault();

    //test to make sure url provided actually links to useable file. 
    //if not, throw an error message.
    imgSize = new Image();
    imgSize.src = url.value;

    setTimeout(function(e) {
        if (imgSize.height <= 0 || imgSize.width <= 0) {
            const h3 = (document.createElement('h3'));
            h3.innerText = 'URL is invalid. Please try again.'
            document.getElementById("urlfield").append(h3);
            setTimeout(function() {
                url.value = '';
                topText.value = '';
                bottomText.value = '';
                h3.remove();
            }, 2000)
        } else {
            renderMeme();
        }
    }, 500);
});

ul.addEventListener("click", function(e) {
    if (e.target.tagName === "BUTTON") {
        e.target.parentElement.parentElement.remove();
    }
});