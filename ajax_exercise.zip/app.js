console.log("Let's get this party started!");
const search = document.getElementById('searchbutton');
const apiRoot = 'http://api.giphy.com/v1/gifs/search';
const api_key = 'MhAodEJIJxQMxW9XqxKjyXfNYdLoOIym';
const picArea = document.querySelector('#pics');

search.addEventListener('click', async function(e) {
   e.preventDefault();
   const response = await axios.get(apiRoot, {params: {'q':$('input').val(), api_key}});
   let img = document.createElement('img');
   img.setAttribute('alt', $('input').val());
   img.src = response.data.data[0].images.original.url;
   picArea.append(img);
});

$('#remove').on('click', function(e) {
    $('img').remove();
})