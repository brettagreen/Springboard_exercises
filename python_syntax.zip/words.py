def print_upper_words(words, must_start_with):
    """TURNS ALL WORDS TO UPPERCASE WOOOOO!!!"""
    word_array = []
    for word in words:
        for letter in must_start_with:
            if word.upper().startswith(letter.upper()):
                word_array.append(word.upper())
                break
    for word in word_array:
        print(word)

print_upper_words(["hello", "hey", "goodbye", "yo", "yes"],
                   must_start_with={"h", "g"})