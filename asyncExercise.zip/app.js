//1.

// $(document).ready(async function() {
//     const resp = await $.getJSON('http://numbersapi.com/9/trivia/?json')
//     console.log(resp.text)
// })

//2.

// $(document).ready(async function() {
//     const li = $('li');
//     const min = 9;
//     const max = 13;
//     let resp = await $.getJSON(`http://numbersapi.com/${min}..${max}/trivia/?json`);
//     for (let x = min; x <= max; x++) {
//         li.append('<ul>'+resp[x.toString()]+'</ul>')
//         console.log(resp[x.toString()])
//     }
// })

// //3.

// $(document).ready(async function() {

//   const facts = await Promise.all([
//     $.getJSON('http://numbersapi.com/9/trivia/?json'),
//     $.getJSON('http://numbersapi.com/9/trivia/?json'),
//     $.getJSON('http://numbersapi.com/9/trivia/?json'),
//     $.getJSON('http://numbersapi.com/9/trivia/?json'),
//     $.getJSON('http://numbersapi.com/9/trivia/?json')
//   ]);  

//     facts.forEach(fact => 
//         $('ul').append('<li>'+fact.text+'</li>')
//     )

// })

//   ////////////////////////////////////////////////////////////////////
//   //////DECK O' CARDS////////////////////////////////////////////////

// //1.

// $(document).ready(async function() {
//   const url_shuffle = 'https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1';

//   let resp = await $.getJSON(url_shuffle);
//   resp = await $.getJSON(`https://deckofcardsapi.com/api/deck/${resp.deck_id}/draw/?count=1`);
//   console.log(resp.cards["0"].value + ' of ' + resp.cards["0"].suit)
// })

// //2.

// $(document).ready(async function() {
//     const url_shuffle = 'https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1';

//     let deckId = null;
  
//     let resp = await $.getJSON(url_shuffle);
//     deckId = resp.deck_id;
//     console.log(deckId);
//     resp = await Promise.all([
//       $.getJSON(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`),
//       $.getJSON(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`)
//     ]);
//     console.log("Card 1: " + resp[0].cards[0].value + ' of ' + resp[0].cards[0].suit);
//     console.log("Card 2: " + resp[1].cards[0].value + ' of ' + resp[1].cards[0].suit);
//   })

//   //3.
  
  // $(document).ready(async function() {
  //   const button = $('#button');
  //   const displayArea = $('#display');

  //   let resp = await $.getJSON('https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1')
  //   let deckId = resp.deck_id;
  //   let url_draw = `https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`;

  //   $(button).on('click', async function() {
  //       let resp = await $.getJSON(url_draw);
  //           console.log(resp.remaining);
  //           if ($('img').length) {
  //               $('img').remove();
  //           }
  //           displayArea.append(
  //               $('<img>', {
  //               src: resp.cards['0'].image
  //               })
  //           );
  //           if (resp.remaining === 0) {
  //               button.remove();
  //               displayArea.append('<h2>That\'s the last card!</h2>');
  //           }
  //       })
  // })

//   ////////////////////////////////////////////////////////////////////
//   //////FURTHER STUDY////////////////////////////////////////////////
  $(document).ready(async function() {

    const fetchThemPokeMen = 'http://pokeapi.co/api/v2/pokemon/';
    const pokeArray = [];
    let count = null;

    let resp = await $.getJSON(`${fetchThemPokeMen}?limit=1500`)
    count = resp.count;
    for (let x = 0; x < 3; x++) {
        const value = Math.floor(Math.random() * (count - 0 + 1));
        pokeArray.push(resp.results[value].url);
    }
    pokeArray.forEach(async url => {
        let stats = await $.getJSON(url);
        let name = stats.name;
        stats = await $.getJSON(stats.species.url);
        for (let x = 0; x < (stats.flavor_text_entries).length; x++) {
            
            if (stats.flavor_text_entries[x].language.name === 'en') {
                console.log(name + ": " + stats.flavor_text_entries[x].flavor_text);
                break;
            }
        }
    })
  })