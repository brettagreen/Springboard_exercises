DROP DATABASE IF EXISTS soccer;

CREATE DATABASE soccer;

\c soccer

CREATE TABLE teams (
    id SERIAL PRIMARY KEY,
    "name" VARCHAR(20) UNIQUE NOT NULL,
    city VARCHAR(20) NOT NULL,
    ranking INT NOT NULL
);

CREATE TABLE players (
    id SERIAL PRIMARY KEY,
    first_name TEXT NOT NULL,
    middle VARCHAR(1),
    last_name TEXT NOT NULL,
    position TEXT CHECK (position IN ('forward', 'defender', 'midfielder', 'goalie')),
    team_id INT REFERENCES teams ON DELETE SET NULL
);

CREATE TABLE referees (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(20) NOT NULL,
    middle VARCHAR(1),
    last_name VARCHAR(20) NOT NULL
);

CREATE TABLE matches (
    id SERIAL PRIMARY KEY,
    team1_id INT REFERENCES teams ON DELETE SET NULL,
    team2_id INT REFERENCES teams ON DELETE SET NULL,
    ref_id INT REFERENCES referees ON DELETE SET NULL,
    match_date DATE NOT NULL,
    "location" VARCHAR(20) DEFAULT 'unknown'
);

CREATE TABLE match_goals (
    id SERIAL PRIMARY KEY,
    player_id INT REFERENCES players ON DELETE SET NULL,
    match_id INT REFERENCES matches ON DELETE CASCADE
);

CREATE TABLE season (
    "start_date" DATE NOT NULL,
    "end_date" DATE NOT NULL
)
