DROP DATABASE IF EXISTS medicalcenter;

CREATE DATABASE medicalcenter;

\c medicalcenter

CREATE TABLE doctors (
    id SERIAL PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    specialty TEXT DEFAULT 'general'
);

CREATE TABLE patients (
    id SERIAL PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    dob DATE NOT NULL
);

CREATE TABLE diseases (
    id SERIAL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "description" TEXT
);

CREATE TABLE visits(
    id SERIAL PRIMARY KEY,
    visit_date DATE NOT NULL,
    doctor_id INT REFERENCES doctors ON DELETE SET NULL,
    patient_id INT REFERENCES patients ON DELETE SET NULL,
    disease_id INT REFERENCES diseases ON DELETE SET NULL
);


INSERT INTO doctors (first_name, last_name, specialty) VALUES ('jesus', 'jones', 'hepatology'), ('warden', 'briggs', 'cardiologist');
INSERT INTO diseases (name) VALUES ('alopecia');
INSERT INTO diseases (name, description) VALUES ('acne', 'zits and stuff');
INSERT INTO patients (first_name, last_name, dob) VALUES ('sheila', 'mcgurdy', '1985-10-01'), ('laura', 'downs', '1950-08-22');
INSERT INTO visits (visit_date, doctor_id, patient_id, disease_id) VALUES ('2020-10-18',1,2,1), ('2019-01-27',2,1,2),
('2021-03-03',1,1,2), ('2022-06-16',2,2,1);

--SELECT v.visit_date, CONCAT(p.first_name, ' ', p.last_name) AS patient_name, CONCAT(doc.first_name, ' ', doc.last_name) AS doctor_name,
--dis.name AS diagnosis FROM visits v JOIN patients p ON v.patient_id = p.id JOIN doctors doc ON v.doctor_id = doc.id
--JOIN diseases dis ON v.disease_id = dis.id;