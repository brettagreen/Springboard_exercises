DROP DATABASE IF EXISTS craigslist;

CREATE DATABASE craigslist;

\c craigslist

CREATE TABLE region (
    id SERIAL PRIMARY KEY,
    region VARCHAR(15) UNIQUE NOT NULL
);

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    region_id INT REFERENCES region ON DELETE SET NULL
);

CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(20) NOT NULL,
    "text" TEXT NOT NULL,
    "user_id" INT REFERENCES users ON DELETE CASCADE,
    "location" VARCHAR(20),
    region_id INT REFERENCES region ON DELETE SET NULL
);

CREATE TABLE categories(
    id SERIAL PRIMARY KEY,
    category VARCHAR(15) UNIQUE NOT NULL
);

CREATE TABLE post_categories (
    id SERIAL PRIMARY KEY,
    post_id INT REFERENCES posts ON DELETE CASCADE,
    category_id INT REFERENCES categories ON DELETE CASCADE
);

INSERT INTO region (region) VALUES ('N. America'), ('S. America'), ('Europe'), ('Africa');
INSERT INTO categories (category) VALUES ('Hardware'), ('Software'), ('Luggage'), ('Odds and ends'), ('Beauty');
INSERT INTO users (first_name, last_name, region_id) VALUES ('Dingus', 'Doolittle', 1), ('Raphael', 'Warmaster', 2), ('Cheese', 'Fredrickson', 3), ('Priscilla', 'Jones', 4);
INSERT INTO posts (title, text, user_id, region_id) VALUES ('Stuff', 'Come get it b4 its gone', 1, 2);
INSERT INTO posts (title, text, user_id, location, region_id) VALUES ('rotten fruit', 'it do be good do', 2, 'my backyard', 1), ('Folding chair', 'as advertised', 3, 'my garage', 3);
INSERT INTO post_categories (post_id, category_id) VALUES (1, 1), (1, 2), (1, 5), (2, 4), (2, 3), (2, 1), (3, 3);