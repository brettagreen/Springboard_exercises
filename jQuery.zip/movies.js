///////////PART 1///////////////////
/*$(window).ready(function() {
    console.log('Let\'s get ready to party with jQuery!');
  });

  $('img').addClass('image-center');

  $('p').last().remove();

  const size = Math.round(Math.random()*100);
  $('h1').css('font-size', size+'px');

  $('ol').append('<li>doggy day care for all!</li>')

  //$('aside').last().remove();
  //console.log($('aside').children());
  $('aside').children().remove();
  $('aside').append('<p>We hereby profusely apologize for the ordered list\'s existence :p</p>');

  $('input').on('change', function(e) {
      let red = $("input").eq(0).val();
      let blue = $("input").eq(1).val();
      let green = $("input").eq(2).val();
      $("body").css("background-color", "rgb(" + red + "," + green + "," + blue + ")");
  });

  $('img').on('click', function() {
    $(this).remove();
  })*/

////////////PART 2/////////////////
$('#start').on('click', function(e) {
    e.preventDefault();
    const title = $('#title').val();
    const rating = $('#rating').val();
    
    $('ul').append(`<li>${title} - ${rating}</li>`);
    
    //$('ul').append('<button class="remove">remove me</button>');
    $('li').last().append('<button class="remove">remove me</button>');
    $('#title').val('');
    $('#rating').val('');
});

$("ul").on("click", ".remove", function(evt) {
    evt.target.parentElement.remove();
});